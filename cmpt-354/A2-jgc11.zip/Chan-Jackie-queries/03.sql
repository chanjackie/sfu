SELECT I.invid
FROM Invoices I