package ca.sfu.jgc11.servingsizecalculator;

import org.junit.Test;

import static junit.framework.Assert.assertEquals;

public class PotTest {
    private Pot p = new Pot("Potty", 10);
    @Test
    public void getNameTest() throws Exception {
        assertEquals("Potty", p.getName());
    }

    @Test
    public void getWeightInGTest() throws Exception {
        assertEquals(10, p.getWeightInG());
    }

    @Test
    public void setWeightTest() throws Exception {
        assertEquals(10, p.getWeightInG());
        p.setWeightInG(20);
        assertEquals(20, p.getWeightInG());
    }

    @Test
    public void setNameTest() throws Exception {
        assertEquals("Potty", p.getName());
        p.setName("Tuppy");
        assertEquals("Tuppy", p.getName());
    }

    @Test (expected = IllegalArgumentException.class)
    public void setWeightExceptionTest() throws Exception {
        p.setWeightInG(-10);
    }

    @Test (expected = IllegalArgumentException.class)
    public void setNameExceptionTest() throws Exception {
        p.setName("");
    }
}
