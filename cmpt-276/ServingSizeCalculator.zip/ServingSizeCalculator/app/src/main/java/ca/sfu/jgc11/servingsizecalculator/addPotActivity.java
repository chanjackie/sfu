package ca.sfu.jgc11.servingsizecalculator;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class addPotActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_pot);

        setupBackButton();
        setupAddPotButton();
    }

    private void setupAddPotButton() {
        Button btn = (Button) findViewById(R.id.btnAddPot);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText nameEdit = (EditText) findViewById(R.id.newPotName);
                String potName = nameEdit.getText().toString();
                EditText weightEdit = (EditText) findViewById(R.id.newPotWeight);
                if (weightEdit.getText().toString().length() > 0 && potName.length() > 0) {
                    int potWeight = Integer.parseInt(weightEdit.getText().toString());
                    Intent intent = new Intent();
                    intent.putExtra("New Pot's Name", potName);
                    intent.putExtra("New Pot's Weight", potWeight);
                    Log.i("MyApp", potName + " " + potWeight);
                    setResult(Activity.RESULT_OK, intent);
                    finish();
                } else if (potName.length() < 1) {
                    Toast.makeText(addPotActivity.this, "Please enter a name for your pot.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(addPotActivity.this, "Make sure pot weight is at least 0g.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setupBackButton() {
        Button btn = (Button) findViewById(R.id.btnGoToPotList);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public static Intent createIntent(Context context) {
        Intent intent = new Intent(context, addPotActivity.class);
        return intent;
    }

    public static Pot getPotFromIntent(Intent data) {
        String pName = data.getStringExtra("New Pot's Name");
        int pWeight = data.getIntExtra("New Pot's Weight", 0);
        Pot p = new Pot(pName, pWeight);
        return p;
    }
}
