package ca.sfu.jgc11.servingsizecalculator;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class calculateActivity extends AppCompatActivity {
    private String pName;
    private int pWeight;
    private TextView potNameView;
    private TextView potWeightView;
    private TextView foodWeightView;
    private TextView servingWeightView;
    private TextView totalWeightEdit;
    private TextView servingNumEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate);

        potNameView = (TextView) findViewById(R.id.potNameView);
        potWeightView = (TextView) findViewById(R.id.potWeightView);
        foodWeightView = (TextView) findViewById(R.id.foodWeightView);
        servingWeightView = (TextView) findViewById(R.id.servingWeightView);
        totalWeightEdit = (TextView) findViewById(R.id.totalWeightEdit);
        servingNumEdit = (TextView) findViewById(R.id.servingNumEdit);
        getIntentData();
        setupBackButton();
        addTextWatchers();
    }

    private void setupBackButton() {
        Button btn = (Button) findViewById(R.id.btnGoToPotList);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void getIntentData() {
        Intent intent = getIntent();
        pName = intent.getStringExtra("calculateActivity - potName");
        pWeight = intent.getIntExtra("calculateActivity - potWeight", 0);
        Log.i("MyApp", "pName: " + pName + " pWeight: " + pWeight);
        potNameView.setText(pName);
        potWeightView.setText(pWeight+"");
        foodWeightView.setText("0");
        servingWeightView.setText("0");
    }

    private void addTextWatchers() {
        totalWeightEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String totalWeight = totalWeightEdit.getText().toString();
                if (totalWeight.length() > 0) {
                    int foodWeight = Integer.parseInt(totalWeight) - pWeight;
                    foodWeightView.setText(""+foodWeight);
                    String servingNum = servingNumEdit.getText().toString();
                    if (servingNum.length() > 0 && !servingNum.equals("0")) {
                        int servingWeight = foodWeight/Integer.parseInt(servingNum);
                        servingWeightView.setText(""+servingWeight);
                    }
                }
            }
        });
        servingNumEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String servingNum = servingNumEdit.getText().toString();
                String totalWeight = totalWeightEdit.getText().toString();
                if (servingNum.length() > 0 && totalWeight.length() > 0 && !servingNum.equals("0")) {
                    int foodWeight = Integer.parseInt(totalWeight) - pWeight;
                    int servingWeight = foodWeight/Integer.parseInt(servingNum);
                    servingWeightView.setText(""+servingWeight);
                }

            }
        });
    }

    public static Intent createIntent(Context context, Pot p) {
        Intent intent = new Intent(context, calculateActivity.class);
        intent.putExtra("calculateActivity - potName", p.getName());
        intent.putExtra("calculateActivity - potWeight", p.getWeightInG());
        Log.i("MyApp", "Put " + p.getName() + " " + p.getWeightInG() + " in intent");
        return intent;
    }
}
