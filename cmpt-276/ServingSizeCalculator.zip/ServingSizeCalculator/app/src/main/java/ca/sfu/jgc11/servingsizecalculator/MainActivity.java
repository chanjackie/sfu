package ca.sfu.jgc11.servingsizecalculator;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private Pot p;
    private PotCollection pColl;
    private ListView list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pot_list);

        setupGoToAddPotButton();
        pColl = new PotCollection();
        list = (ListView) findViewById(R.id.potListView);
        populateListView();
        registerPotClickCallback();
    }

    private void setupGoToAddPotButton() {
        Button btn = (Button) findViewById(R.id.btnGoToAddPot);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = addPotActivity.createIntent(MainActivity.this);
                startActivityForResult(intent, 1);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch(requestCode) {
            case 1:
                if (resultCode == Activity.RESULT_OK) {
                    p = addPotActivity.getPotFromIntent(data);
                    Toast.makeText(MainActivity.this, "New pot added: " + p.getName() + " " + p.getWeightInG() + "g", Toast.LENGTH_SHORT).show();
                    pColl.addPot(p);
                    String logMsg = Arrays.toString(pColl.getPotDescriptions());
                    Log.i("MyApp", "Current pots in collection: " + logMsg);
                    populateListView();
                } else {
                    Log.i("MyApp", "Result failed");
                }
        }
    }

    private void populateListView() {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.pot_item, pColl.getPotDescriptions());
        list.setAdapter(adapter);
    }

    private void registerPotClickCallback() {
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View viewClicked, int position, long id) {
                p = pColl.getPot(position);
                Intent intent = calculateActivity.createIntent(MainActivity.this, p);
                startActivity(intent);
            }
        });
    }
}
