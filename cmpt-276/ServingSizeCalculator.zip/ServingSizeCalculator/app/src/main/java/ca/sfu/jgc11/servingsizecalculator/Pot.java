package ca.sfu.jgc11.servingsizecalculator;

/**
 * Store information about a single pot
 */

public class Pot {
    private String potName;
    private int weight;
    // Set member data based on parameters.
    public Pot(String name, int weightInG) {
        this.potName = name;
        this.weight = weightInG;
    }

    // Return the weight
    public int getWeightInG() {
        return weight;
    }

    // Set the weight. Throws IllegalArgumentException if weight is less than 0.
    public void setWeightInG(int weightInG) {
        if (weightInG < 0) {
            throw new IllegalArgumentException("Weight must be greater than 0.");
        } else {
            this.weight = weightInG;
        }
    }

    // Return the name.
    public String getName() {
        return potName;
    }

    // Set the name. Throws IllegalArgumentException if name is an empty string (length 0),
    // or if name is a null-reference.
    public void setName(String name) {
        if (name.length() == 0 || name.equals(null)) {
            throw new IllegalArgumentException("Name cannot be empty or NULL.");
        } else {
            this.potName = name;
        }
    }
}
