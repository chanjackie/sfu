package ca.sfu.jgc11.portandstarboard;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Game portStarboardGame;
    private TextView sideText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        portStarboardGame = new Game();
        sideText = (TextView) findViewById(R.id.sideText);
        sideText.setText(portStarboardGame.getChosenSideName());

        Button btnShowLeft = (Button) findViewById(R.id.btnShowLeft);
        Button btnShowRight = (Button) findViewById(R.id.btnShowRight);
        Button btnMeansLeft = (Button) findViewById(R.id.btnMeansLeft);
        Button btnMeansRight = (Button) findViewById(R.id.btnMeansRight);
        btnShowRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("MyApp", "Starboard (right) is green!");
                Toast.makeText(getApplicationContext(), "Starboard (right) is green!", Toast.LENGTH_SHORT).show();
            }
        });
        btnShowLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("MyApp", "Port (left) is red!");
                Toast.makeText(getApplicationContext(), "Port (left) is red!", Toast.LENGTH_SHORT).show();
            }
        });
        btnMeansLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (portStarboardGame.checkIfCorrect(Game.Side.PORT)) {
                    Log.i("MyApp", "User guess of PORT was correct!");
                    Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_SHORT).show();
                } else {
                    Log.i("MyApp", "User guess of PORT was incorrect.");
                    Toast.makeText(getApplicationContext(), "Incorrect. :(", Toast.LENGTH_SHORT).show();
                }
                portStarboardGame = new Game();
                sideText.setText(portStarboardGame.getChosenSideName());
            }
        });
        btnMeansRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (portStarboardGame.checkIfCorrect(Game.Side.STARBOARD)) {
                    Log.i("MyApp", "User guess of STARBOARD was correct!");
                    Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_SHORT).show();
                } else {
                    Log.i("MyApp", "User guess of STARBOARD was incorrect.");
                    Toast.makeText(getApplicationContext(), "Incorrect. :(", Toast.LENGTH_SHORT).show();
                }
                portStarboardGame = new Game();
                sideText.setText(portStarboardGame.getChosenSideName());
            }
        });
    }
}
