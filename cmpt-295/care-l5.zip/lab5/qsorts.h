
void qsort295_1(int *A, int n);
void qsort295_2(int *A, int n);

