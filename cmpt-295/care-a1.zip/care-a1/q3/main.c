
#include <stdio.h>

int mystery(char *, int);

char *str = "Good mood food.";

void main () {
	int n = 15;
	printf("The return value was:  %d.\n", mystery(str,n));
	return;
}
