
// Lab 1:  mainline routine

#include <stdio.h>

int times(int, int);

void main () {
    int a = 6;
    int b = 9;
    int answer = times(a, b);

    printf("The answer is %d.\n", answer);
    return;
}

