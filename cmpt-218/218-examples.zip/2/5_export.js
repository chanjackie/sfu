var user = require('./User.js');

var u1 = new user('Bobby','Chan',24);
u1.fullName();
