console.log(typeof(a));
console.log(typeof(b));

function a(){ }

var b = function(){};
