Application found in:

/jgc11/asn4/

To start:

pm2 start server.js