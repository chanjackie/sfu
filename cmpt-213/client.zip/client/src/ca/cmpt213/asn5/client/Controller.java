package ca.cmpt213.asn5.client;

public class Controller {
}
