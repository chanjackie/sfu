package ca.cmpt213.as3.models;

public class TokimonField {

    private int numTokimons;
    private int numFokimons;
    private int[][] field;

    public TokimonField(int numTokis, int numFokis) {
        numTokimons = numTokis;
        numFokimons = numFokis;
    }


}
