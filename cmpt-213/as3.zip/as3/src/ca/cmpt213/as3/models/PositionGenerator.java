package ca.cmpt213.as3.models;

public class PositionGenerator {
    public static int[][] GeneratePositions(int[] argAmounts, int numArgs, int gridSize) {
        assert(numArgs == argAmounts.length);
        int[][] field = new int[gridSize][gridSize];

        return field;
    }
}
