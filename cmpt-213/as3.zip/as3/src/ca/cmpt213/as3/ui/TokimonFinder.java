package ca.cmpt213.as3.ui;

public class TokimonFinder {

    public static void main(String[] args) {

    }
}
