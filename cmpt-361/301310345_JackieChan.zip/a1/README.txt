Got help from discussion on CMPT 361 Discord Channel
Various small parts (e.g. how to quickly make a deep copy) from stack overflow