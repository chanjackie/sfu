#include "klock.h"
#include <stdio.h>
#include <time.h>
#include "list.h"
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <errno.h>
#include <pthread.h>
#include <semaphore.h>

// each thread has its own node, which is used in cycle detection
typedef struct{
	struct nodeStruct* threadNode;
	pthread_t threadID;
}Thread;


long unsigned int uniqueID = 0;
sem_t mutex;
int init = 0; // for initial mutex initialization
struct nodeStruct *head = NULL; // head will point to the graph
int numNodes = 0; // number of nodes in graph
_Bool isCycle;
int numThreads = 0; // for cleanup
int numLocks = 0; // for cleanup
Thread *arr; // for cleanup
SmartLock *arrLock; // for cleanup



void init_lock(SmartLock* lock) {
	pthread_mutex_init(&(lock->mutex), NULL);
	pthread_mutex_init(&(lock->mutex2), NULL);
	if(init == 0) {
		sem_init(&mutex,0,1);
		init = 1;
	}
	// init lock with is own unique id and node
	lock->lockID = uniqueID;
	lock->lockNode = List_createNode(lock->lockID);
	uniqueID++;
	numLocks++;
	arrLock = realloc(arrLock, sizeof(SmartLock)*numLocks); // for cleanup of locks
	arrLock[numLocks-1] = *lock;

}

_Bool checkForCycles() {
	printf("in cycles: %d\n", numNodes);
	struct nodeStruct *first = head;

	//iterates through graph, checking for cycles
	// cycle exists if the "pivot" node is repeated during the iteration through the graph
	// first = pivot, second = node being compared
	// returns: true on cycle, false otherwise
	for(int i =0;i<numNodes;i++) {
		struct nodeStruct *second = first;
		while(second->next != NULL) {
			second = second ->next;
			if(first->item == second->item) {
				printf("same\n");
				return true;
			}
			else {
				printf("Pivot = %lu , compare = %lu\n", first->item, second->item);
			}
		}
		if(first->next != NULL) {
			first = first->next;
		}
	}
	return false;
}

// for testing
void printHead() {
	struct nodeStruct *x = head;
	printf("HEAD: ");
	for(int i = 0;i<numNodes;i++) {
		printf("%lu ", x->item);
		if(x->next != NULL) {
			x = x->next;
		}
	}
	printf("\n");
}



// if thread (process) calls locK(), it is requesting for the lock (resource) i.e request edge
// if pthread_mutex_lock blocks, the lock (resource) is being used
// returns 0 on cycle, 1 on completion
int lock(SmartLock* lock) {
	printf("NUM NODES: %d\n", numNodes);
	// mutex to prevent race conditions
	sem_wait(&mutex);
	Thread mThread;
	mThread.threadID = pthread_self();
	mThread.threadNode = List_createNode(mThread.threadID);
	numThreads++;
	// keep pointers to allocated threads for cleanup
	arr = realloc(arr,sizeof(Thread)*numThreads);
	arr[numThreads-1] = mThread;
	printf("%lu\n", arr[numThreads-1].threadID);
	printf("Currently in process %lu with lock %lu\n", mThread.threadID, lock->lockID);
	// cycle detection
	// the graph created is POINTING to locks+processes
	// the graph will change with the changing of edges, even if the graph (head) isnt directly manipulated
	// ex: after a lock is unlocked, the allocation edge is removed from the lock and the graph
	if(head != NULL) {
		// first sign of possible cycle
		// thread may be linking to a resource that is linked to a process ... that links to caling thread
		if(List_getLastNodeID(head) == mThread.threadID) {
			// second sign of possible cycle
			// if lockNode->next is null, resource is free so no cycle is possible
			if(lock->lockNode->next != NULL) {
				printf("in locknodenext\n");
				// inserts the lock and the process that node is connecting to into graph
				List_insertTail(&(head), lock->lockNode);
				// keep track of node count in graph
				numNodes = numNodes + 2;
				isCycle = checkForCycles();
				// graph has no cycle, allow the thread to request the resource
				if(!isCycle) {
					printf("no cycle\n");
					mThread.threadNode->next = lock->lockNode;
				}
			}
		}
		// thread is not connected to the graph, no possible cycle
		else {
			mThread.threadNode->next = lock->lockNode;
		}
	}
	// head not just established, therefore all resources are currently free
	else {
		printf("in else for outer\n");
		mThread.threadNode->next = lock->lockNode;
	}
	printHead();
	// if a cycle was detected, the request edge from calling thread to resource is not established
	if(isCycle) {
		printf("cycle, no edge created\n");
		mThread.threadNode->next = NULL;
	}
	else {
		//printf("Process %lu is linked to lock %lu\n", mThread->threadID, mThread->threadNode->next->item);
	}
	sem_post(&mutex);
	// returns 0 and resets value of cycle
	if(isCycle) {
		isCycle = false;
		return 0;
	}
	// check if lock is being used anywhere else
	// only one process can use one lock at a time
	pthread_mutex_lock(&(lock->mutex));
	// lock (resource) is allocated to this calling thread (process)
	lock->lockNode->next = mThread.threadNode;
	// Un-request the edge
	mThread.threadNode->next = NULL;
	// creates a lock+process groupinh and install into graph
	if(head== NULL) {
		List_insertTail(&(head), (lock->lockNode));
		numNodes = numNodes + 2;
	}
	printf("last id: %lu\n", List_getLastNodeID(head));
	//checkForCycles();
	printf("Lock %lu is allocated to process %lu\n", lock->lockID, lock->lockNode->next->item);
	printf("returning for id =  %lu\n", lock->lockID);
	return 1;
}

void unlock(SmartLock* lock) {
	pthread_mutex_unlock(&(lock->mutex));
	// remove allocation edge
	lock->lockNode->next = NULL;
	printf("nodes: %d\n", numNodes);

}


/*
 * Cleanup any dynamic allocated memory for SmartLock to avoid memory leak
 * You can assume that cleanup will always be the last function call
 * in main function of the test cases.
 */
void cleanup() {
	for(int i=0;i<numThreads;i++) {
		printf("ID of thread: %lu\n", arr[i].threadID);
		free(arr[i].threadNode);
		//free(&(arr[i]));
	}
	free(arr);
	for(int z = 0;z<numLocks;z++) {
		free(arrLock[z].lockNode);
	}
	free(arrLock);
}
