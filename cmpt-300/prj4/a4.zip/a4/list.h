#ifndef LIST_H
#define LIST_H

struct nodeStruct {
	long unsigned int item;
	struct nodeStruct *next;
};
struct nodeStruct* List_createNode(long unsigned int item);
void List_insertHead(struct nodeStruct **headRed, struct nodeStruct *node);
void List_insertTail (struct nodeStruct **headRef, struct nodeStruct *node);
int List_countNodes (struct nodeStruct *head);
struct nodeStruct* List_findNode(struct nodeStruct *head, long unsigned int item);
void List_deleteNode (struct nodeStruct **headRef, struct nodeStruct *node);
void List_sort (struct nodeStruct **headRef);
long unsigned int List_getLastNodeID(struct nodeStruct *head);




#endif