#include "list.h"
#include <assert.h>
#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


/*
 * Allocate memory for a node of type struct nodeStruct and initialize
 * it with the value item. Return a pointer to the new node.
 */
struct nodeStruct* List_createNode(long unsigned int item) {
	struct nodeStruct *newNode = malloc(sizeof(struct nodeStruct));
	newNode->item = item;
	newNode->next = NULL;
	//printf("New node created with item %d\n", newNode->item);
	return newNode;
}

/*
 * Insert node at the head of the list.
 */
void List_insertHead (struct nodeStruct **headRef, struct nodeStruct *node) {
	if(*headRef == NULL) {
		//printf("List is empty, creating new head\n");
		*headRef = node;
	}
	// Head already exists, shift pointer of head to new node
	// and change new head pointer to old head
	else {
		node->next = *headRef;
		*headRef = node;
	}
}



/*
 * Insert node after the tail of the list.
 */
void List_insertTail (struct nodeStruct **headRef, struct nodeStruct *node) {
	struct nodeStruct *nodeInc = *headRef;
	int len = List_countNodes(*headRef);
	if(len == 0) {
		//printf("List is empty, insert tail is inserting at the head.\n");
		List_insertHead(headRef, node);
	}
	else {
		for(int i =0;i<len-1;i++) {
			nodeInc = nodeInc->next;
		}
		nodeInc->next = node;
		//printf("%d\n", nodeInc->item);
	}
	
}


/*
 * Count number of nodes in the list.
 * Return 0 if the list is empty, i.e., head == NULL
 */
int List_countNodes (struct nodeStruct *head) {
	int nodeCount = 0;
	struct nodeStruct *counter = head;
	if(head == NULL) {
		//printf("List is empty\n");
		return 0;
	}
	else {
		// head is a node
		nodeCount++;
		// iterate through list
		while(1) {
			if(counter->next != NULL) {
				nodeCount++;
				counter= counter->next;
			}
			else {
				return nodeCount;
			}

		}
	}
}


/*
 * Return the first node holding the value item, return NULL if none found
 */
struct nodeStruct* List_findNode(struct nodeStruct *head, long unsigned int item) {
	struct nodeStruct *foundNode = head;
	for(int i =0;i<List_countNodes(head);i++) {
		//printf("%d \n", foundNode->item);
		if(foundNode->item == item) {
			return foundNode;
		}
		foundNode = foundNode->next;
	}
	//printf("Node with item %d not found in list \n", item);
	return foundNode;
}

/*
 * Delete node from the list and free memory allocated to it.
 * This function assumes that node has been properly set to a valid node 
 * in the list. For example, the client code may have found it by calling 
 * List_findNode(). If the list contains only one node, the head of the list 
 * should be set to NULL.
 */
void List_deleteNode (struct nodeStruct **headRef, struct nodeStruct *node) {
	struct nodeStruct *copyOfHeadForInc = *headRef;
	struct nodeStruct *nodeBeforeFoundNode;
	if(copyOfHeadForInc->next == NULL) {
		*headRef = NULL;
		printf("Deleting single head node\n");
	}
	else {
		copyOfHeadForInc = copyOfHeadForInc->next;
		nodeBeforeFoundNode = *headRef;
		//printf("%d %d \n", copyOfHeadForInc->item, nodeBeforeFoundNode->item);
		for(int i=0;i<List_countNodes(*headRef);i++) {
			//Delete if referenced node is at the head and list length > 1
			if(nodeBeforeFoundNode->item == node->item) {
				if(i == 0) {
					// Assign head to node pointed to by old head		
					*headRef = copyOfHeadForInc;
					//printf("%d\n", **headRef);
					free(nodeBeforeFoundNode);
					break;
				}
			}
			else if(copyOfHeadForInc->item == node->item){	
				//printf("Node with value %d is now freed\n", copyOfHeadForInc->item);
				if(copyOfHeadForInc->next == NULL) {
					//printf("%d\n", nodeBeforeFoundNode->next->item);
					nodeBeforeFoundNode->next = NULL;
					*headRef = nodeBeforeFoundNode;
					//printf("%d\n", **headRef);
					//printf("%d\n", nodeBeforeFoundNode->next);
					free(copyOfHeadForInc);
				}
				else {
					nodeBeforeFoundNode->next = copyOfHeadForInc->next;
					free(copyOfHeadForInc);
				}
				
				break;
			}
			else {
				copyOfHeadForInc = copyOfHeadForInc->next;
				nodeBeforeFoundNode = nodeBeforeFoundNode->next;
			}
		}
		
	}

}


/*
 * Sort the list in ascending order based on the item field.
 * Any sorting algorithm is fine.
 */
struct nodeStruct* List_findMiddle(struct nodeStruct* headCopy) {
	struct nodeStruct *first = headCopy;
	struct nodeStruct* second = headCopy;
	// Check if the next two nodes aren't null
	while(second->next != NULL && second->next->next != NULL) {
		first = first->next; //increment pointer to middle 
		second = second->next->next; 
	}
	return first; // returns pointer to middle
}

struct nodeStruct* List_mergeBothLists(struct nodeStruct* firstHalf, struct nodeStruct* secondHalf) {
	struct nodeStruct* currentNode = NULL;
	if(firstHalf == NULL) {
		return secondHalf;
	}
	else if(secondHalf == NULL) {
		return firstHalf;
	}

	if(firstHalf->item <= secondHalf->item) {
		currentNode = firstHalf;
		currentNode->next = List_mergeBothLists(firstHalf->next, secondHalf); // Recursive call to sort
	}
	else if(secondHalf->item <= firstHalf->item) {
		currentNode = secondHalf;
		currentNode->next = List_mergeBothLists(firstHalf, secondHalf->next); // Recursive call to sort
	}
	return currentNode;
}

void List_sort (struct nodeStruct **headRef) {
	struct nodeStruct* headCopy = *headRef;
	if(headCopy == NULL || headCopy->next == NULL) { // Check if list is empty or if list length = 1
		return;
	}
	struct nodeStruct* middle= List_findMiddle(headCopy);
	struct nodeStruct* secondHalf = middle->next; // Pointer to head of second list
	middle->next = NULL; // Divides list
	List_sort(&headCopy); // Recursive call
	List_sort(&secondHalf);
	*headRef = List_mergeBothLists(headCopy, secondHalf); // Join the two halves


}

long unsigned int List_getLastNodeID(struct nodeStruct *head) {
	int size = List_countNodes(head);
	struct nodeStruct *x = head;
	for(int i = 0;i<size-1;i++) {
		x = x->next;
	}
	return x->item;
}
