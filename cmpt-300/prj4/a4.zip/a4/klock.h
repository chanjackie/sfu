#ifndef __KLOCK_H__
#define __KLOCK_H__

#include <pthread.h>

typedef struct {
	 pthread_mutex_t mutex;
	 pthread_mutex_t mutex2;
	 long unsigned int lockID;
	 struct nodeStruct *lockNode;
} SmartLock;

void init_lock(SmartLock* lock);
int lock(SmartLock* lock);
void unlock(SmartLock* lock);
void cleanup();

#endif
