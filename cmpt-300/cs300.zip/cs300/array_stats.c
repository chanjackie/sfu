#include  "array_stats.h"
#include <linux/kernel.h>
#include <linux/uaccess.h>
#define EINVAL 22
#define EFAULT 14

asmlinkage long sys_array_stats(struct array_stats *stats, long data[], long size) {
	int i = 0;
	long currData = 0;
	struct array_stats currStat = {0};
	printk("starting\n");
	if(size <= 0) {
		printk("einval\n");
		return -EINVAL;
	}
	else {
		for(i;i<size;i++) {
			// set currData to the current data value
			if(copy_from_user(&currData, &data[i], 8) == 0);
			else {
				return -EFAULT;
			}
			//printk("currData = %ld ", currData);
			if(i == 0) {
				currStat.max = currData;
				currStat.min = currData;
			//	printk("init min max = %ld ", currData);
			}
			else if(currData > currStat.max) {
				currStat.max = currData;
			//	printk("new max = %ld ", currData);
			}
			else if (currData < currStat.min) {
				currStat.min = currData;
			//	printk("new min = %ld ", currData);
			}
			currStat.sum += currData;
			//printk("new sum = %ld\n", currStat.sum);
		}
		printk("kernel lv stats = %ld %ld %ld\n", currStat.min, currStat.max, currStat.sum);

		if(copy_to_user(&stats->min, &currStat.min, 8) == 0);
		else {
			return -EFAULT;
		}
		if(copy_to_user(&stats->max, &currStat.max, 8) == 0);
		else {
			return -EFAULT;
		}
		if(copy_to_user(&stats->sum, &currStat.sum, 8) == 0);
		else {
			return -EFAULT;
		}
	}
	printk("ending\n");
	return 20;
	
}
