#include "process_ancestors.h"
#include <linux/sched.h>
#include <stdio.h>
#include <unistd.h>

#define PROCESSANCESTORS 341
int main(int argc, char* argv[])  {
	struct process_info first;
	struct process_info second;
	struct process_info third;
	struct process_info fourth;
	struct process_info fifth;
	struct process_info sixth;
	struct process_info a;
	struct process_info b;
	struct process_info mArray[] = {first,second,third,fourth,fifth,sixth,a,b};
	long mFilled;
	printf("Diving into kernel mode\n");
	long ret = syscall(PROCESSANCESTORS, mArray, 8, &mFilled);
	printf("Rising to user level = %ld\n", ret);
	for(int i = 0;i<5;i++) {
		printf("id = %lu name = %s state = %lu uid = %lu vol = %lu invol = %lu children = %lu siblings = %lu\n", mArray[i].pid, 
			mArray[i].name, mArray[i].state, mArray[i].uid, mArray[i].nivcsw, mArray[i].nvcsw,
			mArray[i].num_children, mArray[i].num_siblings);
	}
	printf("num filled = %lu\n", mFilled);
	
}
