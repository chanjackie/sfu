#include "process_ancestors.h"
#include <linux/kernel.h>

#include <linux/uaccess.h>
#include <linux/sched.h>
#include <linux/cred.h>

#define EINVAL 22
#define EFAULT 14
#define ANCESTOR_NAME_LEN 16
// long pid;                     /* Process ID */
//     char name[ANCESTOR_NAME_LEN]; /* Program name of process */
//     long state;                   /* Current process state */
//     long uid;                     /* User ID of process owner */
//     long nvcsw;                   /* # voluntary context switches */
//     long nivcsw;                  /* # involuntary context switches */
//     long num_children;            /* # children process has */
//     long num_siblings;            // # sibling process has */

asmlinkage long sys_process_ancestors(struct process_info info_array[], long size, long *num_filled) {
	long pid = 0;
	int i = 0;
	int z = 0;
	struct task_struct *mTask = current;
	uid_t uid = 0;
	long vol = 0;
	long invol = 0;
	long state = 0;
	char *name;
	char copiedName[ANCESTOR_NAME_LEN];
	long kern_num_filled = 0;
	long num_children =0;
	long num_siblings = 0;
	struct list_head *pos;

	if(size <= 0) {
		return -EINVAL;
	}
	else {
		for(i; i<size; i++) {
			memset(copiedName,0,strlen(copiedName));
			num_children = 0;
			num_siblings = 0;
			pid = mTask->pid;
			name = mTask->comm;
			// copy char pointer to char array
			for(z=0;z<strlen(name);z++) {
				copiedName[z] = name[z];
			}
			uid = (mTask->cred)->uid.val;
			vol = mTask->nivcsw;
			invol = mTask->nvcsw;
			state = mTask->state;

			list_for_each(pos, &mTask->children) {
				num_children++;
			}
			list_for_each(pos, &mTask->sibling) {
				num_siblings++;
			}
			if(mTask->parent == mTask && pid == 0) {
				kern_num_filled++;
				if(copy_to_user(&info_array[i].pid,&pid,8) == 0);
				else {
					return -EFAULT;
				}
				printk("pid of process = %ld", pid);
				if(copy_to_user(&info_array[i].name, &copiedName, ANCESTOR_NAME_LEN) == 0);
				else {
					return -EFAULT;
				}	
				printk("name of process = %s", copiedName);
				if(copy_to_user(&info_array[i].uid,&uid,sizeof(uid_t)) == 0);
				else {
					return -EFAULT;
				}
				printk("uid = %d", uid);
				if(copy_to_user(&info_array[i].state,&state,8) == 0);
				else {
					return -EFAULT;
				}
				printk("state = %lu",state);
				if(copy_to_user(&info_array[i].num_children,&num_children,8) == 0);
				else {
					return -EFAULT;
				}
				printk("num_children = %lu", num_children);
				if(copy_to_user(&info_array[i].num_siblings,&num_siblings,8) == 0);
				else {
					return -EFAULT;
				}
				printk("num_siblings = %lu", num_siblings);
				if(copy_to_user(&info_array[i].nivcsw,&vol,8) == 0);
				else {
					return -EFAULT;
				}
				printk("voluntary = %lu", vol);
				if(copy_to_user(&info_array[i].nvcsw,&invol,8) == 0);
				else {
					return -EFAULT;
				}
				printk("involuntary = %lu", invol );
				break;
			}
			else {
				kern_num_filled++;
				if(copy_to_user(&info_array[i].pid,&pid,8) == 0);
				else {
					return -EFAULT;
				}
				printk("pid of process = %ld", pid);
				if(copy_to_user(&info_array[i].name, &copiedName, ANCESTOR_NAME_LEN) == 0);
				else {
					return -EFAULT;
				}
				printk("name of process = %s", copiedName);
				if(copy_to_user(&info_array[i].uid,&uid,sizeof(uid_t)) == 0);
				else {
					return -EFAULT;
				}
				printk("uid = %d", uid);
				if(copy_to_user(&info_array[i].state,&state,8) == 0);
				else {
					return -EFAULT;
				}
				printk("state = %lu",state);
				if(copy_to_user(&info_array[i].num_children,&num_children,8) == 0);
				else {
					return -EFAULT;
				}
				printk("num_children = %lu", num_children);
				if(copy_to_user(&info_array[i].num_siblings,&num_siblings,8) == 0);
				else {
					return -EFAULT;
				}
				printk("num_siblings = %lu", num_siblings);
				if(copy_to_user(&info_array[i].nivcsw,&vol,8) == 0);
				else {
					return -EFAULT;
				}
				printk("voluntary = %lu", vol);
				if(copy_to_user(&info_array[i].nvcsw,&invol,8) == 0);
				else {
					return -EFAULT;
				}
				printk("involuntary = %lu", invol );
				
			}
			mTask = mTask->parent;
		}
	}
	if(copy_to_user(num_filled, &kern_num_filled, 8) == 0); 
	else {
		return -EFAULT;
	}
	printk("kern filled = %lu", kern_num_filled);
	// for(z=0;z<kern_num_filled;z++) {
	// 	printk("%lu %lu %lu %s", info_array[z].pid,info_array[z].num_children,info_array[z].num_siblings,
	// 								info_array[z].name);
	// }
	printk("returning 0");
	return 0;


}

