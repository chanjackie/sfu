// ID cbdaaf363f8f199871c6a35420714712

#include <numeric>
#include <string_view>
#include <vector>

#include "task07.h"

