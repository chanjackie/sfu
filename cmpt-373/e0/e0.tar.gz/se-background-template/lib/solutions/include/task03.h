// ID cbdaaf363f8f199871c6a35420714712
#pragma once

#include "Support.h"

ex0::ButterPats task03(ex0::HotPotato potato);