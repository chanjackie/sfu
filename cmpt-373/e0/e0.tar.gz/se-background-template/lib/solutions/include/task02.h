// ID cbdaaf363f8f199871c6a35420714712
#pragma once

int task02(int &val);