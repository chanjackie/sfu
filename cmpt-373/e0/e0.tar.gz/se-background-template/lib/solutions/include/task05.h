// ID cbdaaf363f8f199871c6a35420714712
#pragma once

#include "Support.h"

class Task05 {
public:
	Task05(ex0::HotPotato&);

	void butterExcessively();
private:
	ex0::HotPotato &potato;
};