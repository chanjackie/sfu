// ID cbdaaf363f8f199871c6a35420714712
#pragma once

#include <string>
#include <unordered_map>
#include "Support.h"

std::string task07(std::string val, std::unordered_map<char, const std::string> map);