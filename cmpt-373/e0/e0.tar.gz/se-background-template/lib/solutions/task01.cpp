// ID cbdaaf363f8f199871c6a35420714712

#include "task01.h"

int task01(int num) {
	return num+1;
}