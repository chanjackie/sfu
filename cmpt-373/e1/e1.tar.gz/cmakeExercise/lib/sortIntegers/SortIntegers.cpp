#include <algorithm>
#include <vector>

void
sortIntegers(std::vector<int> &numbers) {
  std::sort(std::begin(numbers), std::end(numbers));
}