#include "task06.h"

#include <algorithm>
#include <numeric>


