
#include "task02.h"

#include <cmath>

