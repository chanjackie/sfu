
#include "task01.h"

#include <algorithm>
#include <cctype>


