
#include "task03.h"

#include <algorithm>

