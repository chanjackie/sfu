#include "task05.h"

#include <algorithm>
#include <numeric>

